package login.sumit.registration;

public interface MyProvider {

	String username="root";
	String pwd="";
	String connUrl="jdbc:mysql://127.0.0.1:5432/baza";
	
}
