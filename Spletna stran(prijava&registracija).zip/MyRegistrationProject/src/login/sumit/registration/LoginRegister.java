package login.sumit.registration;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/LoginRegister")
public class LoginRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
    public LoginRegister() {
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		CustomerDAO cd = new CustomerDAOImpl();
		String ID = request.getParameter("username");
		String password = request.getParameter("password");
		String PrijavaType=request.getParameter("potrdi");
		Customer c= new Customer();
		c=cd.getCustomer(ID,password);
		if(PrijavaType.equals("Prijava") && c!=null && c.getUporabniskoime()!=null) {
			request.getRequestDispatcher("Index.jsp").forward(request, response);;
		}
			else if (PrijavaType.equals("Registracija")) {
			c.setID(ID);
			c.setUporabniskoime(request.getParameter("name"));
			c.setPassword(password);
			cd.insertCustomer(c);
			request.setAttribute("successmessage", "Registracija uspe�na !!");
			request.getRequestDispatcher("Registracija.jsp").forward(request, response);
		}else {
			request.setAttribute("message", "Data not found !!");
			request.getRequestDispatcher("Registracija.jsp").forward(request, response);
		}
	
	
	
	
	
	
	
	
	
	
	
	
	}

}
