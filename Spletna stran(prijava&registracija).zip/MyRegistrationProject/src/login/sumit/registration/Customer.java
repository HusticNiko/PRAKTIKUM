package login.sumit.registration;

public class Customer {
	
	private String ID;

	public String getID() {
		return ID;
	}
	public void setID(String ID) {
		this.ID = ID;
	}
	private String Uporabniskoime;
	public String getUporabniskoime() {
		return Uporabniskoime;
	}
	public void setUporabniskoime(String uporabniskoime) {
		Uporabniskoime = uporabniskoime;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	private String password;
	
}
