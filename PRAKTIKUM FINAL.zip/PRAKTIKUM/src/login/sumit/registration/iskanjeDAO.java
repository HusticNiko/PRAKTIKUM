package login.sumit.registration;

public interface iskanjeDAO {
	
	public int insertiskanje(iskanje is);
	public iskanje getiskanje(String stslicice,String zbirke);
	

}
